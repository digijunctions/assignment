<?php

namespace App\Repositories\Base;

use App\Repositories\Base\Traits\CrudMethods;

abstract class CrudRepository extends BaseRepository
{
    use CrudMethods;
}