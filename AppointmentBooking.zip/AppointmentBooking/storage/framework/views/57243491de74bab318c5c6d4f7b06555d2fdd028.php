<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <ol class="breadcrumb">
      <li><a href="/home">Home</a></li>
      <li class="active">Users</li>
    </ol>

    <div class="panel">
        <div class="panel-heading">
            <h3>Users</h3>
            <br>

            <div class="row">
                <div class="col-sm-2">
                        <a href="<?php echo e(route('home.users.create')); ?>" class="btn btn-primary"> <i class="fa fa-plus"></i> User</a>
                </div>

            </div>

            <br>

        </div>
        <div class="panel-body">
            <div class="table-responsive">
                <table class="table table-stripped table-hover">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Type</th>
                            <th class="action"></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td><?php echo e($user->type); ?></td>
                            <td class="text-right">
                            <?php echo Form::open(['route' => ['home.users.destroy', $user->id], 'method' => 'delete']); ?>

                                <div class='btn-group'>
                                    <a href="<?php echo e(route('home.users.show', $user->id)); ?>" class="btn btn-sm btn-default"><i class="fa fa-eye"></i></a>
                                    <a href="<?php echo e(route('home.users.edit', $user->id)); ?>" class="btn btn-sm btn-default"><i class="fa fa-pencil"></i></a>
                                    <?php echo Form::button('<i class="fa fa-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-sm', 'onclick' => "return confirm('Are you sure to delete this item?')"]); ?>

                                </div>
                            <?php echo Form::close(); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <?php echo $users->render(); ?>

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\AppointmentBooking\resources\views/home/users/index.blade.php ENDPATH**/ ?>