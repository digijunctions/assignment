<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <ol class="breadcrumb">
      <li><a href="/home">Home</a></li>
      <li><a href="<?php echo e(route('home.providers.index')); ?>">Providers</a></li>
      <li class="active">New Provider</li>
    </ol>

    <div class="panel">
        <div class="panel-heading">
            <h3>New Provider</h3>
        </div>
        <div class="panel-body">
            <?php echo Form::open(['route' => 'home.providers.store', 'files' => true, 'id' => 'provider-form']); ?>    
        
                <?php echo $__env->make('home.providers.fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="form-group col-xs-12 col-sm-12">
                    <?php echo Form::submit('Save', ['class' => 'btn btn-success']); ?>

                </div>

            <?php echo Form::close(); ?>  
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\AppointmentBooking\resources\views/home/providers/create.blade.php ENDPATH**/ ?>