<?php $__env->startSection('content'); ?>
<div class="container">
            
    <?php if(auth()->guard()->check()): ?>
        <?php if(Auth::user()->isClient()): ?>
            <book-add-appointments></book-add-appointments>
        <?php else: ?>
            <div class="row text-center" style="color: #FFFFFF; margin-bottom: 10px;">
                Hi, <?php echo e(Auth::user()->name); ?>

            </div>
            <div class="row text-center">
                <div class="col-sm-12">
                    <a href="<?php echo e(route('home.index')); ?>" class="btn btn-primary">Go to Admin Panel</a>
                </div>
            </div>    
        <?php endif; ?>
    <?php endif; ?>

    <?php if(auth()->guard()->guest()): ?>
    <div class="row text-center">
        <div class="col-sm-12">
            <a href="<?php echo e(route('login')); ?>" class="btn btn-primary">Login to Book Appointments</a>
        </div>
    </div>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php echo $__env->make('js.config', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="<?php echo e(mix('js/site.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.basic', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\AppointmentBooking\resources\views/site.blade.php ENDPATH**/ ?>