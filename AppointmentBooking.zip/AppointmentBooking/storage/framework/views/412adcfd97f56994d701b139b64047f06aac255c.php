<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <ol class="breadcrumb">
      <li><a href="/home">Home</a></li>
      <li class="active">Clients</li>
    </ol>

    <div class="panel">
        <div class="panel-heading">
            <h3>Clients</h3>
            <br>

            <div class="row">
                <div class="col-sm-2">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-client', App\Models\User::class)): ?>
                        <a href="<?php echo e(route('home.clients.create')); ?>" class="btn btn-primary"> <i class="fa fa-plus"></i> Client</a>
                    <?php endif; ?>
                </div>

            </div>

            <br>

        </div>
        <div class="panel-body">
            <div class="table-responsive">
                <table class="table table-stripped table-hover">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th class="action"></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($client->name); ?></td>
                            <td><?php echo e($client->email); ?></td>
                            <td class="text-right">
                            <?php echo Form::open(['route' => ['home.clients.destroy', $client->id], 'method' => 'delete']); ?>

                                <div class='btn-group'>
                                    <a href="<?php echo e(route('home.clients.show', $client->id)); ?>" class="btn btn-sm btn-default"><i class="fa fa-eye"></i></a>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update-client', App\Models\User::class)): ?>
                                        <a href="<?php echo e(route('home.clients.edit', $client->id)); ?>" class="btn btn-sm btn-default"><i class="fa fa-pencil"></i></a>
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-client', App\Models\User::class)): ?>
                                        <?php echo Form::button('<i class="fa fa-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-sm', 'onclick' => "return confirm('Are you sure to delete this clients? This will remove all the client appointments!')"]); ?>

                                    <?php endif; ?>
                                </div>
                            <?php echo Form::close(); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <?php echo $clients->render(); ?>

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\AppointmentBooking\resources\views/home/clients/index.blade.php ENDPATH**/ ?>