<nav class="navbar navbar-default navbar-static-top">
    <div class="container-fluid">
        <div class="navbar-header">

            <!-- Collapsed Hamburger -->
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                <span class="sr-only">Toggle Navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>

        </div>

        <div class="collapse navbar-collapse" id="app-navbar-collapse">
            <!-- Left Side Of Navbar -->
            <ul class="nav navbar-nav visible-xs">
                <?php if(auth()->guard()->check()): ?>
                    <li class="<?php echo e(isActiveRoute('home.index')); ?>">
                        <a href="<?php echo e(route('home.index')); ?>">
                            <i class="fa fa-calendar" aria-hidden="true"></i>
                            Calendar
                        </a>
                    </li>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-client', App\Models\User::class)): ?>
                        <li class="<?php echo e(areActiveRoutes(['home.clients.index', 'home.clients.create', 'home.clients.edit', 'home.clients.show'])); ?>">
                            <a href="<?php echo e(route('home.clients.index')); ?>">
                                <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                Clients
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-provider', App\Models\User::class)): ?>
                        <li class="<?php echo e(areActiveRoutes(['home.providers.index', 'home.providers.create', 'home.providers.edit', 'home.providers.show'])); ?>">
                            <a href="<?php echo e(route('home.providers.index')); ?>">
                                <i class="fa fa-user-md" aria-hidden="true"></i>
                                Providers
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', App\Models\Service::class)): ?>
                        <li class="<?php echo e(areActiveRoutes(['home.services.index', 'home.services.create', 'home.services.edit', 'home.services.show'])); ?>">
                            <a href="<?php echo e(route('home.services.index')); ?>">
                                <i class="fa fa-wrench" aria-hidden="true"></i>
                                Services
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage', App\Models\User::class)): ?>
                        <li class="<?php echo e(areActiveRoutes(['home.users.index', 'home.users.create', 'home.users.edit', 'home.users.show'])); ?>">
                            <a href="<?php echo e(route('home.users.index')); ?>">
                                <i class="fa fa-users" aria-hidden="true"></i>
                                Users
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage', App\Models\Settings::class)): ?>
                        <li class="<?php echo e(isActiveRoute('home.settings.index')); ?>">
                            <a href="<?php echo e(route('home.settings.index')); ?>">
                                <i class="fa fa-cog" aria-hidden="true"></i>
                                Settings
                            </a>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>
            </ul>

            <!-- Right Side Of Navbar -->
            <ul class="nav navbar-nav navbar-right">
                <!-- Authentication Links -->
                <?php if(auth()->guard()->guest()): ?>
                    <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                <?php else: ?>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                            <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                        </a>

                        <ul class="dropdown-menu" role="menu">
                            <li>
                                <a href="<?php echo e(route('logout')); ?>"
                                    onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();">
                                    Logout
                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo e(csrf_field()); ?>

                                </form>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>
            </ul>

        </div>
    </div>
</nav><?php /**PATH D:\AppointmentBooking\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>