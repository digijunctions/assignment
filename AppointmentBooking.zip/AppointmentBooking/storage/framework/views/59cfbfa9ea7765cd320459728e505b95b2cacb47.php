<script>
    var App = {
        // Appointments
        appointmentsUrl: "<?php echo e(route('home.appointments.index')); ?>",
        addAppointmentUrl: "<?php echo e(route('home.appointments.store')); ?>",
        addClientAppointmentUrl: "<?php echo e(route('ajax.appointments.storeClientAppointment')); ?>",
        updateAppointmentUrl: "<?php echo e(route('home.appointments.update', ':id')); ?>",
        removeAppointmentUrl: "<?php echo e(route('home.appointments.destroy', ':id')); ?>",

        // Clients
        clientsUrl: "<?php echo e(route('home.clients.index')); ?>",

        // Providers
        providersUrl: "<?php echo e(route('home.providers.index')); ?>",

        // Services
        servicesUrl: "<?php echo e(route('ajax.services.index')); ?>",
        serviceAvailableTimesUrl: "<?php echo e(route('ajax.services.times', ':id')); ?>",
    }
</script><?php /**PATH D:\AppointmentBooking\resources\views/js/config.blade.php ENDPATH**/ ?>