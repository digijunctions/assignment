
<div class="form-group col-xs-12 col-sm-6 required">
    <?php echo Form::label('name', 'Name'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control', 'required' => 'required']); ?>

</div>

<div class="form-group col-xs-12 col-sm-6 required">
    <?php echo Form::label('email', 'Email'); ?>

    <?php echo Form::email('email', null, ['class' => 'form-control', 'required' => 'required']); ?>

</div>

<div class="form-group col-xs-12 col-sm-6">
    <?php echo Form::label('password', 'Password (optional)'); ?>

    <?php echo Form::password('password', ['class' => 'form-control']); ?>

</div>

<div class="form-group col-xs-12 col-sm-6">
    <?php echo Form::label('password_confirmation', 'Password Confirmation'); ?>

    <?php echo Form::password('password_confirmation', ['class' => 'form-control']); ?>

</div>

<div class="col-sm-12">
    <div class="panel">
        <div class="panel-heading">
            <h4>Address Information</h4>
        </div>
        <div class="panel-body">
            <div class="form-group col-xs-12 col-sm-12">
                <?php echo Form::label('address', 'Address'); ?>

                <?php echo Form::text('address', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group col-xs-12 col-sm-6">
                <?php echo Form::label('city', 'City'); ?>

                <?php echo Form::text('city', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group col-xs-12 col-sm-3">
                <?php echo Form::label('state', 'State'); ?>

                <?php echo Form::text('state', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group col-xs-12 col-sm-3">
                <?php echo Form::label('zip_code', 'Zip Code'); ?>

                <?php echo Form::text('zip_code', null, ['class' => 'form-control']); ?>

            </div>
        </div>
    </div>
</div>

<div class="col-sm-12">
    <h4>Phones</h4>

    <book-user-phones 
        form="client-form" 
        phones="<?php echo e(isset($client) ? $client->phones : '[]'); ?>">
    </book-user-phones>
</div><?php /**PATH D:\AppointmentBooking\resources\views/home/clients/fields.blade.php ENDPATH**/ ?>