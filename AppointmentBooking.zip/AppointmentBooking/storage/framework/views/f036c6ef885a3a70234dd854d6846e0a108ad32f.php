<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Appoitment Booking system</title>

    <!-- Styles -->
    <link href="<?php echo e(mix('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(mix('css/basic.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">

    <style>
        body {
            background-image: url(<?php echo e(asset('assets/images/sidebar-back.jpg')); ?>);
        }
    </style>

    <?php echo $__env->yieldContent('styles'); ?>

</head>

<body>
    <div class="loader-overlay">
        <div class="loader"></div>
    </div>

    <div class="app-wrapper" id="app">
        <?php echo $__env->make('layouts.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php if(Route::has('login')): ?>
            <div class="top-right links">
                <?php if(auth()->guard()->check()): ?>
                    <?php if(!Auth::user()->isClient()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('logout')); ?>"
                                    onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();">
                                    Logout
                                </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo e(csrf_field()); ?>

                        </form>
                    <?php endif; ?>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>">Login</a>
                    <a href="<?php echo e(route('register')); ?>">Register</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <div class="container text-center">
            <div class="main-logo">
                <a href="<?php echo e(route('site')); ?>">
                    <img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="">
                </a>
            </div>
        </div>

        <?php echo $__env->yieldContent('content'); ?>
        <div class="background-opacity"></div>

    </div>

    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH D:\AppointmentBooking\resources\views/layouts/basic.blade.php ENDPATH**/ ?>