<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <?php if(Auth::user()->isProvider()): ?>
            <book-calendar provider="<?php echo e(Auth::user()->id); ?>" business-hours="<?php echo e(!$businessHours->isEmpty() ? $businessHours : 'false'); ?>" ref="book-calendar"></book-calendar>
            <?php else: ?>
            <book-calendar business-hours="<?php echo e(!$businessHours->isEmpty() ? $businessHours : 'false'); ?>" ref="book-calendar"></book-calendar>            
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\AppointmentBooking\resources\views/home.blade.php ENDPATH**/ ?>