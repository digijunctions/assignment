<div class="sidebar-header">
    <!-- Branding Image -->
    <a href="<?php echo e(route('home.index')); ?>">
        <img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="">
    </a>
</div>
<div class="sidebar-inner">
    <ul class="nav nav-sidebar">
        <?php if(auth()->guard()->check()): ?>
            <li class="<?php echo e(isActiveRoute('home.index')); ?>">
                <a href="<?php echo e(route('home.index')); ?>">
                    <i class="fa fa-calendar" aria-hidden="true"></i>
                    Calendar
                </a>
            </li>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-client', App\Models\User::class)): ?>
                <li class="<?php echo e(areActiveRoutes(['home.clients.index', 'home.clients.create', 'home.clients.edit', 'home.clients.show'])); ?>">
                    <a href="<?php echo e(route('home.clients.index')); ?>">
                        <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                        Clients
                    </a>
                </li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-provider', App\Models\User::class)): ?>
                <li class="<?php echo e(areActiveRoutes(['home.providers.index', 'home.providers.create', 'home.providers.edit', 'home.providers.show'])); ?>">
                    <a href="<?php echo e(route('home.providers.index')); ?>">
                        <i class="fa fa-user-md" aria-hidden="true"></i>
                        Providers
                    </a>
                </li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', App\Models\Service::class)): ?>
                <li class="<?php echo e(areActiveRoutes(['home.services.index', 'home.services.create', 'home.services.edit', 'home.services.show'])); ?>">
                    <a href="<?php echo e(route('home.services.index')); ?>">
                        <i class="fa fa-wrench" aria-hidden="true"></i>
                        Services
                    </a>
                </li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage', App\Models\User::class)): ?>
                <li class="<?php echo e(areActiveRoutes(['home.users.index', 'home.users.create', 'home.users.edit', 'home.users.show'])); ?>">
                    <a href="<?php echo e(route('home.users.index')); ?>">
                        <i class="fa fa-users" aria-hidden="true"></i>
                        Users
                    </a>
                </li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage', App\Models\Settings::class)): ?>
                <li class="<?php echo e(isActiveRoute('home.settings.index')); ?>">
                    <a href="<?php echo e(route('home.settings.index')); ?>">
                        <i class="fa fa-cog" aria-hidden="true"></i>
                        Settings
                    </a>
                </li>
            <?php endif; ?>
        <?php endif; ?>
    </ul>
</div>
<div class="sidebar-background" style="background-image: url(<?php echo e(asset('assets/images/sidebar-back.jpg')); ?>);"></div><?php /**PATH D:\AppointmentBooking\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>