<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <ol class="breadcrumb">
      <li><a href="/home">Home</a></li>
      <li class="active">Settings</li>
    </ol>

    <div class="panel">
        <div class="panel-heading">
            <h3>Settings</h3>
        </div>
        <div class="panel-body">
            <?php echo Form::open(['route' => 'home.settings.store', 'id' => 'settings-form']); ?>


                <?php echo $__env->make('home.settings.fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="form-group col-xs-12 col-sm-12">
                    <?php echo Form::submit('Save', ['class' => 'btn btn-success']); ?>

                </div>

            <?php echo Form::close(); ?>

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\AppointmentBooking\resources\views/home/settings/index.blade.php ENDPATH**/ ?>