-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 07, 2020 at 11:36 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `appointment_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `id` int(10) UNSIGNED NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` enum('reserved','confirmed','finished','canceled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'reserved',
  `client_id` int(10) UNSIGNED NOT NULL,
  `service_id` int(10) UNSIGNED NOT NULL,
  `provider_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `start` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `end` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`id`, `description`, `status`, `client_id`, `service_id`, `provider_id`, `created_at`, `updated_at`, `start`, `end`) VALUES
(1, NULL, 'reserved', 3, 1, 1, '2020-06-06 02:46:23', '2020-06-06 02:46:23', '2020-06-06 13:45:00', '2020-06-06 13:50:00'),
(4, NULL, 'reserved', 2, 1, 4, '2020-06-06 02:56:42', '2020-06-06 02:56:42', '2020-07-01 06:00:00', '2020-07-01 06:05:00'),
(5, NULL, 'reserved', 3, 1, 4, '2020-06-06 03:22:57', '2020-06-06 03:22:57', '2020-06-30 06:00:00', '2020-06-30 06:05:00'),
(6, NULL, 'finished', 3, 1, 4, '2020-06-07 03:59:57', '2020-06-07 03:59:57', '2020-06-07 14:59:00', '2020-06-07 15:59:00');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2014_10_13_100000_create_user_phones_table', 1),
(4, '2014_10_13_300000_create_services_table', 1),
(5, '2014_10_13_400000_create_provider_service_table', 1),
(6, '2014_10_13_500000_create_appointments_table', 1),
(7, '2017_11_01_184348_create_settings_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('yogesh@gmail.com', '$2y$10$SFSJesF/pEbH8kB4tZQhAuRmMrMZCGGOnzrJFWPBltCNikhKBHSCK', '2020-06-07 03:58:30');

-- --------------------------------------------------------

--
-- Table structure for table `provider_service`
--

CREATE TABLE `provider_service` (
  `id` int(10) UNSIGNED NOT NULL,
  `provider_id` int(10) UNSIGNED NOT NULL,
  `service_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `provider_service`
--

INSERT INTO `provider_service` (`id`, `provider_id`, `service_id`, `created_at`, `updated_at`) VALUES
(1, 4, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `duration` int(11) NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `name`, `duration`, `description`, `image`, `created_at`, `updated_at`) VALUES
(1, 'test', 5, 'teasr', NULL, '2020-06-06 02:45:22', '2020-06-06 02:45:22');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `name`, `value`, `created_at`, `updated_at`) VALUES
(1, 'company_name', 'Godrej property', '2020-06-06 02:22:22', '2020-06-06 02:22:22'),
(2, 'company_email', 'Godrej_property@gmail.com', '2020-06-06 02:22:22', '2020-06-06 02:22:22'),
(3, 'email_notify', '1', '2020-06-06 02:22:22', '2020-06-06 02:22:22'),
(4, 'appointment_reserved_notify', '1', '2020-06-06 02:22:22', '2020-06-06 02:22:22'),
(5, 'business_plans', '[{\"daysOfWeek\":{\"sunday\":\"true\",\"monday\":\"true\",\"tuesday\":\"true\",\"wednesday\":\"true\",\"thursday\":\"true\",\"friday\":\"true\",\"saturday\":\"true\"},\"start\":\"06:00\",\"end\":\"18:00\"}]', '2020-06-06 02:22:22', '2020-06-06 02:22:22');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zip_code` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` enum('client','secretary','provider','admin') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'client',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `image`, `description`, `address`, `city`, `state`, `zip_code`, `type`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Yogesh', 'yogesh@gmail.com', '$2y$10$cIPKW0xT6rvyD5wOIFy1g.SwIYOPbyAAcF2VaIB51ctStu9wmImNm', NULL, 'test', NULL, NULL, NULL, NULL, 'admin', '1oMdwwyeT8BG41KNjg0hkF1pTU7d6pIWU8R3U6NYQ6FLgLo9aNWYmYtafdZ0', '2020-06-05 18:30:00', '2020-06-05 18:30:00'),
(2, 'yogesh', 'yogesh@yogesh.com', '$2y$10$mqESCRX3fGgML6LWH5/3FOOAE8bp0xL8rXGzIuzRONkxHQJH.ZXw2', NULL, NULL, NULL, NULL, NULL, NULL, 'client', 'nCDX0JyzfOrkI4jRY1NX72AvYKGmUlBnP6A6GYFRUszIY7YuhigVm6XnrJXr', '2020-06-06 00:58:24', '2020-06-06 00:58:24'),
(3, 'santosh', 'santosh@munde.com', '$2y$10$IpDmWWnnLqUcWhatwAVTA.XxYvqedvho8BJ5PkLePlFQ3FxyPvjpO', NULL, NULL, NULL, NULL, NULL, NULL, 'client', '8VMiWicy0vVrGeTwp1dzI0faPIhwlp29oW4Pofqb6v60ok7ZGZ6FGYqglqLM', '2020-06-06 01:52:14', '2020-06-06 01:52:14'),
(4, 'Test', 'Test@yogesh.com', '$2y$10$djjDKiT/rwIqFMZATPjEquunvfqjKAZfOHRE3v8Q64VQWgIczWGmG', NULL, 'Test@yogesh.com', 'Test@yogesh.com', 'Test@yogesh.com', 'Test@yogesh.com', 'Test@yogesh.com', 'provider', NULL, '2020-06-06 02:44:18', '2020-06-06 02:44:18');

-- --------------------------------------------------------

--
-- Table structure for table `user_phones`
--

CREATE TABLE `user_phones` (
  `id` int(10) UNSIGNED NOT NULL,
  `phone` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_phones`
--

INSERT INTO `user_phones` (`id`, `phone`, `user_id`, `created_at`, `updated_at`) VALUES
(1, '9579263798', 4, '2020-06-06 02:44:18', '2020-06-06 02:44:18'),
(2, '96325874', 4, '2020-06-06 02:44:18', '2020-06-06 02:44:18');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `appointments_client_id_foreign` (`client_id`),
  ADD KEY `appointments_service_id_foreign` (`service_id`),
  ADD KEY `appointments_provider_id_foreign` (`provider_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `provider_service`
--
ALTER TABLE `provider_service`
  ADD PRIMARY KEY (`id`),
  ADD KEY `provider_service_provider_id_foreign` (`provider_id`),
  ADD KEY `provider_service_service_id_foreign` (`service_id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `settings_name_unique` (`name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_phones`
--
ALTER TABLE `user_phones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_phones_user_id_foreign` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `provider_service`
--
ALTER TABLE `provider_service`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user_phones`
--
ALTER TABLE `user_phones`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointments`
--
ALTER TABLE `appointments`
  ADD CONSTRAINT `appointments_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `appointments_provider_id_foreign` FOREIGN KEY (`provider_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `appointments_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`);

--
-- Constraints for table `provider_service`
--
ALTER TABLE `provider_service`
  ADD CONSTRAINT `provider_service_provider_id_foreign` FOREIGN KEY (`provider_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `provider_service_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`);

--
-- Constraints for table `user_phones`
--
ALTER TABLE `user_phones`
  ADD CONSTRAINT `user_phones_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
