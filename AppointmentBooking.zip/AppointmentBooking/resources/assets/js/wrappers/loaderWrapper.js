'use strict';

module.exports = {

    show: function() {
        $(".loader-overlay").show();
    },

    hide: function() {
        $(".loader-overlay").hide();
    }

}