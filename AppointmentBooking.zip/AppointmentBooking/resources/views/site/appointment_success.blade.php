@extends('layouts.basic')

@section('content')
<div class="container text-center" style="color: white">
    <h3>Success creating your Appointment!!</h3>
</div>
@endsection